#include <map>
#include <vector>
#include "tf/tf.h"
#include <iostream>
#include "precisedocking/coorconv.h"
#include "ros/ros.h"
#include <algorithm>
#include "ros/time.h"
#include "Eigen/Eigen"
#include "std_msgs/String.h"
#include "nav_msgs/Odometry.h"
#include "sensor_msgs/NavSatFix.h"
#include <boost/thread/thread.hpp>
#include "precisedocking/pubmsg.h"
#include "precisedocking/conversion.h"
#include "precisedocking/chccgi610nav.h"
#include "precisedocking/AprilTagDetection.h"
#include "precisedocking/AprilTagDetectionArray.h"
#include <message_filters/subscriber.h>
#include <message_filters/synchronizer.h>
#include <message_filters/time_synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <geometry_msgs/PoseStamped.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/Quaternion.h>
#include <queue>
#include <Eigen/Dense>
#include <geometry_msgs/Point.h>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>


#define loading_in_tag 1     //进入装载区的标签
#define loading_out_tag 10   //离开装载区的标签
#define weighting_in_tag 11  //进入过磅区的标签
#define weighting_out_tag 18 //离开过磅区的标签
/*
    总节点：融合Node A、Node B、Node C
    Node A:GNSS + IMU + Wheel Speed, 发布经纬度；
        发布的话题名："/chccgi610_nav"
        消息结构：chccgi610nav.msg
    Node B:Lidar-Inertial-Odometry,发布经纬度；lio-sam,后续使用LIO_SAM_6AXIS
        发布的话题名："/odometry/imu"
        消息结构："nav_msgs/Odometry"
    Node C:视觉标记识别 + 定位，发布经纬度；AprilTag
        发布的话题："/tag_detections"
        消息结构：AprilTagDetection.msg、AprilTagDetectionArray.msg
*/
//typedef message_filters::sync_policies::ApproximateTime<nav_msgs::Odometry, precisedocking::AprilTagDetectionArray> syncPolicy;
//typedef message_filters::sync_policies::ApproximateTime<precisedocking::chccgi610nav,nav_msgs::Odometry> syncPolicy;

#define FUDU 57.29577951
int ros_count=0;
double gps_lon=0;
double gps_lat=0;
double gps_x=0;
double gps_y=0;

double gps_roll=0;
double gps_pitch=0;
double gps_yaw=0;
//lio-sam
double lio_x[10]={0};
double lio_y[10]={0};
double last_lio_x=0;
double last_lio_y=0;
double detal_lio_x=0;
double detal_lio_y=0;
double detal_lon=0;
double detal_lat=0;
double new_lio_x=0;
double new_lio_y=0;
double init_lio_x=0;
double init_lio_y=0;
double detal_lio_x_r=0;
double detal_lio_y_r=0;

double x_outage; //zhongduan
double y_outage;
double outage_distance;
double error;
double error0_2,error2_5,error5_10,error10_20,error20_30,error30_40,error40_50;
double covariance1,covariance2;

//Eigen::Matrix<Scalar, 3, Eigen::Dynamic> cloud_gps (3, npts);
//Eigen::Matrix<Scalar, 3, Eigen::Dynamic> cloud_odom (3, npts);
std::queue<geometry_msgs::Point> gps_queue;
std::queue<geometry_msgs::Point> odom_queue;
geometry_msgs::Point gps_point;
geometry_msgs::Point odom_point;
Eigen::Matrix3Xd point_gps_matrix(3,100);
Eigen::Matrix<double, 3, 3> Matrix_r;
Eigen::Matrix<double, 3, 1> Matrix_t;


int count=0;
//merge
double merge_lat=0;
double merge_lon=0;

double deg=13.722;

coorconv::WGS84Corr wgs;
coorconv::WGS84Corr merge_wgs;
coorconv::UTMCoor utm;
coorconv::UTMCoor merge_utm;
coorconv::UTMCoor merge_utm_r;
precisedocking::pubmsg pmsg;       //发布的消息类型
static bool isGPSonline = true;     // GPS是否在线
static bool isloadingarea = false;  // 是否是装载区
static bool isweighingarea = false; // 是否是过磅区
static bool merge_mark=false;  //融合标志
static bool gpsdown = false; //是否关闭过gps
std::string merge_msg_out_topic_;  //融合数据输出话题
int SNWM;



double wrapToPm(double a_num, const double a_max)
{
    if (a_num >= a_max)
    {
        a_num -= 2.0 * a_max;
    }
    return a_num;
}
double wrapToPmPi(const double a_angle_rad)
{
    return wrapToPm(a_angle_rad, M_PI);
}


/// @brief 四元数转roll、pitch、yaw
/// @param input 输入对象的四元数
/// @param pubmsg 输出对象的roll、pitch、yaw
void getrpy(nav_msgs::Odometry &input, precisedocking::pubmsg &pubmsg)
{
    //四元数归一化
    float sum_orientations =sqrt( pow(input.pose.pose.orientation.x ,2)+ pow(input.pose.pose.orientation.y ,2)+ 
                                pow(input.pose.pose.orientation.z ,2) + pow(input.pose.pose.orientation.w,2));
    input.pose.pose.orientation.x = input.pose.pose.orientation.x /sum_orientations;
    input.pose.pose.orientation.y = input.pose.pose.orientation.y / sum_orientations;
    input.pose.pose.orientation.z = input.pose.pose.orientation.z / sum_orientations;
    input.pose.pose.orientation.w = input.pose.pose.orientation.w / sum_orientations;
    //转换
    double imu_roll, imu_pitch, imu_yaw;
    tf::Quaternion imu_orientation;
    tf::quaternionMsgToTF(input.pose.pose.orientation, imu_orientation);
    tf::Matrix3x3(imu_orientation).getRPY(imu_roll, imu_pitch, imu_yaw);	// ZYX
    pubmsg.roll = wrapToPmPi(imu_roll);
    pubmsg.pitch = wrapToPmPi(imu_pitch);
    pubmsg.heading = wrapToPmPi(imu_yaw);
}
/// @brief 订阅发布类
class SubscribeAndPublish
{
public:
    SubscribeAndPublish(ros::NodeHandle &_nh);
    void callbackA(const precisedocking::chccgi610nav::ConstPtr &chccgi);
    //void callbackB(const nav_msgs::OdometryConstPtr &odomsg);
    void callbackB(const nav_msgs::OdometryConstPtr &odomsg);

   // void callbackBC(const nav_msgs::OdometryConstPtr &odomsg, const precisedocking::AprilTagDetectionArrayConstPtr &aprilmsg);
    //void callbackAB(const precisedocking::chccgi610nav::ConstPtr &chccgi , const nav_msgs::OdometryConstPtr &odomsg);
private:
    ros::NodeHandle n_;
    ros::Publisher pub_merge;
    ros::Publisher pub_nav;
    ros::Subscriber sub_A;
    ros::Subscriber sub_B;
};

/// @brief 订阅发布类构造函数
/// @param _nh ros操作句柄
SubscribeAndPublish::SubscribeAndPublish(ros::NodeHandle &_nh)
{
    n_ = _nh;
    //发布话题
    pub_merge = n_.advertise<precisedocking::pubmsg>(merge_msg_out_topic_, 1000);
    //nodeA
    sub_A = n_.subscribe<precisedocking::chccgi610nav>("/chccgi610_nav",100,&SubscribeAndPublish::callbackA,this);
   // sub_B = n_.subscribe< nav_msgs::Odometry>("/odometry/imu",100,&SubscribeAndPublish::callbackB,this);
    sub_B = n_.subscribe< nav_msgs::Odometry>("/Odometry",100,&SubscribeAndPublish::callbackB,this);
/*
   //nodeA与nodeB消息同步
    message_filters::Subscriber<precisedocking::chccgi610nav> sub_A(n_, "/chccgi610_nav", 1000);
    message_filters::Subscriber<nav_msgs::Odometry> sub_B(n_, "/odometry/imu", 1000);
    //message_filters::Subscriber<precisedocking::AprilTagDetectionArray> sub_C(n_, "/tag_detections", 1000);
    message_filters::Synchronizer<syncPolicy> syncAB(syncPolicy(10), sub_A, sub_B);
    syncAB.registerCallback(boost::bind(&SubscribeAndPublish::callbackAB, this, _1, _2));
*/
    //nodeB与nodeC消息同步
  //  message_filters::Subscriber<nav_msgs::Odometry> sub_B(n_, "/Odometry/imu", 1000);
   // message_filters::Subscriber<precisedocking::AprilTagDetectionArray> sub_C(n_, "/tag_detections", 1000);
  //  message_filters::Synchronizer<syncPolicy> syncBC(syncPolicy(10), sub_B, sub_C);
    //syncBC.registerCallback(boost::bind(&SubscribeAndPublish::callbackBC, this, _1, _2));
    ros::MultiThreadedSpinner s(4); //多线程
    ros::spin(s);
}

/// @brief 用于node A以及从串口获取的gpgst数据回调函数
/// @param chccgi nodeA 消息对象
/// @param gpgstmsg gpgst消息对象

void SubscribeAndPublish::callbackA(const precisedocking::chccgi610nav::ConstPtr &chccgi)
{
    int snwm = chccgi->nsv1;
std::cout << "snwm:" <<snwm<< std::endl;
std::cout << "SNWM:" <<SNWM<< std::endl;
        int hdop = chccgi->hdop;

        wgs.lon =chccgi->lon;//wgs
        wgs.lat =chccgi->lat;

 
	//printf("wgs.lon:%.8f\n",wgs.lon);
	//printf("wgs.lat:%.8f\n",wgs.lat);
   // wgs.lon =118.70165219;//wgs
  //  wgs.lat =32.03068784;

    //如果满足条件说明，GPS信号正常，即不在装载区
    if (snwm < SNWM||snwm == SNWM )
    {
        //在装载区
        isGPSonline = false;
        printf("========================NO-GPS================================\n");


    }
if (snwm > SNWM)
    {
        //在装载区
        isGPSonline = true;
        printf("========================GPS================================\n");
    }
    pmsg.gpsweek = chccgi->gpsweek;
    pmsg.gpstime = chccgi->gpstime;
    pmsg.alt = chccgi->nsv1;////////
    pmsg.header = chccgi->header;
    pmsg.pitch = chccgi->pitch;
    pmsg.roll = chccgi->roll;
    pmsg.heading = chccgi->heading;
    //如果GPS在线，且不在装载区或过磅区，则由node A发布经纬度
    if (isGPSonline && odom_point.x < 40)////////////////////
    {
        pmsg.header = chccgi->header;
        pmsg.pitch = chccgi->pitch;
        pmsg.roll = chccgi->roll;
        pmsg.heading = chccgi->heading;
        pmsg.lat = chccgi->lat;
        pmsg.lon = chccgi->lon;
//pmsg.lon = chccgi->lon;chccgi->nsv1;


	LatLonToUTMXY(wgs,utm);
	//gps_x=utm.x-660730;//gps 转换的xy//////////////////////////////////////////////////////////////////////////////////////////
	//gps_y=utm.y-3.54514e+06;
    gps_x=utm.x;//gps 转换的xy//////////////////////////////////////////////////////////////////////////////////////////
	gps_y=utm.y;
	printf("gps_x%.8f\n",gps_x);
	printf("utm.x:%.8f\n",utm.x);
	printf("utm.y:%.8f\n",utm.y);
    printf("%f",error5_10);

/////////////////////////////////////////////////////////////////

        gps_point.x=gps_x;
        gps_point.y=gps_y;
        gps_point.z=0;
        //geometry_msgs::Point::ConstPtr& gps_point_rf = gps_point;
        gps_queue.push(gps_point);

        while (gps_queue.size() > 100) 
        {
            gps_queue.pop();
        }


        std::queue<geometry_msgs::Point> copy_queue = gps_queue;
        for (int i = 0; i < gps_queue.size(); i++) {
            geometry_msgs::Point p = copy_queue.front();
            copy_queue.pop();

            Eigen::Vector3d v(p.x, p.y, p.z);
            
            point_gps_matrix.col(i) = v;

         }
        std::stringstream ss;
        ss << point_gps_matrix.transpose();
        ROS_INFO_STREAM(ss.str());
///////////////////////////////////////////////////////////////////

	//UTMXYToLatLon(utm,50,0,wgs);	
	//printf("utm.lat:%.8f\n",wgs.lat);
	//printf("utm.lon:%.8f\n",wgs.lon);	

	gps_lon= chccgi->lon;//gps lon  lat
	gps_lat= chccgi->lat;
    pmsg.error=0;


        //发布数据
	std::cout << "发布GPS数据!!" << std::endl;
        pub_merge.publish(pmsg);
    }
}
/// @brief 用于node B
/// @param odomsg nodeB 消息结构指针对象
/// @param 

void SubscribeAndPublish::callbackB(const nav_msgs::OdometryConstPtr &odomsg)
{
	//创建融合数据对象 使用nav_msg::Odometry对象接收
    nav_msgs::Odometry Odomsg;
    Odomsg.pose.pose.orientation.x = odomsg->pose.pose.orientation.x ;
    Odomsg.pose.pose.orientation.y = odomsg->pose.pose.orientation.y;
    Odomsg.pose.pose.orientation.z = odomsg->pose.pose.orientation.z ;
    Odomsg.pose.pose.orientation.w = odomsg->pose.pose.orientation.w;
/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
    covariance1=odomsg->pose.covariance[0];
    covariance2=odomsg->pose.covariance[7];
        odom_point.x=odomsg->pose.pose.position.x;
        odom_point.y=odomsg->pose.pose.position.y;
        odom_point.z=0;
        //geometry_msgs::Point::ConstPtr& gps_point_rf = gps_point;
        odom_queue.push(odom_point);
        Eigen::Matrix3Xd point_odom_matrix(3,100);
        while (odom_queue.size() > 100) 
        {
            odom_queue.pop();
        }


        std::queue<geometry_msgs::Point> copy2_queue = odom_queue;
        for (int i = 0; i < odom_queue.size(); i++) {
            geometry_msgs::Point p2 = copy2_queue.front();
            copy2_queue.pop();

            Eigen::Vector3d v2(p2.x, p2.y, p2.z);
            
            point_odom_matrix.col(i) = v2;

         }
        std::stringstream s2;
        s2 << point_odom_matrix.transpose();
        ROS_INFO_STREAM(s2.str());

       if(isGPSonline && odom_point.x < 40)
       {
         Eigen::Matrix<double,3,4> Matrix_a;
         Matrix_a<<1,0,0,0,0,1,0,0,0,0,1,0;
         Eigen::Matrix<double,4,3> Matrix_b;
         Matrix_b<<1,0,0,0,1,0,0,0,1,0,0,0;

        Eigen::Matrix<double, 4, 4> rt = Eigen::umeyama (point_odom_matrix, point_gps_matrix, false);
        Matrix_r=Matrix_a * rt *Matrix_b;
        Matrix_t<<rt(0,3),rt(1,3),rt(2,3);
        std::stringstream s3;
        s3 << rt;
        ROS_INFO_STREAM(s3.str());
        std::stringstream s4;
        s4 << Matrix_r;
        ROS_INFO_STREAM(s4.str());
        std::stringstream s5;
        s5 << Matrix_t;
        ROS_INFO_STREAM(s5.str());
        x_outage=odom_point.x;
        y_outage=odom_point.y;
        }
///////////////////////////////////////////////////////////////////

//////////////////////
 //printf("odomsg->pose.pose.orientation.x :%.8f\n",odomsg->pose.pose.orientation.x );
   // printf("Odomsg.pose.pose.orientation.x :%.8f\n",Odomsg.pose.pose.orientation.x );
    getrpy(Odomsg, pmsg);
    pmsg.roll=pmsg.roll*FUDU;
    pmsg.heading=pmsg.heading*FUDU;
    pmsg.pitch=pmsg.pitch*FUDU;////////////////8为工程误差
	if(pmsg.roll<0)     pmsg.roll=pmsg.roll+360; 
if(pmsg.heading<0) {pmsg.heading=pmsg.heading+360;}
if(pmsg.pitch<0)   pmsg.pitch=pmsg.pitch+360;


//0.05s
	
        pmsg.header = odomsg->header;
	//if (isGPSonline){
//有gps
		//init_lio_x=odomsg->pose.pose.position.x;
		//init_lio_y=odomsg->pose.pose.position.y;
                
	//}


		//new_lio_x=odomsg->pose.pose.position.x;
		//new_lio_y=odomsg->pose.pose.position.y;

   	 if (!isGPSonline || odom_point.x >40 || odom_point.x==40){
    //if (odom_point.x > 14 || odom_point.x == 14){
      //在装载区
/////////////////
		//if(merge_mark){
                
                //detal_lio_x=new_lio_x-init_lio_x;
                //detal_lio_y=new_lio_y-init_lio_y;
                
                //detal_lio_x_r=detal_lio_x*cos(deg/FUDU)-detal_lio_y*sin(deg/FUDU);
                //detal_lio_y_r=detal_lio_x*sin(deg/FUDU)+detal_lio_y*cos(deg/FUDU);
		//merge_utm.x=gps_x+detal_lio_x;
		//merge_utm.y=gps_y+detal_lio_y;
                //merge_utm_r.x=merge_utm.x*cos(deg/FUDU)-merge_utm.y*sin(deg/FUDU);
                //merge_utm_r.y=merge_utm.x*sin(deg/FUDU)+merge_utm.y*cos(deg/FUDU);//逆时针旋转deg度
                Eigen::Matrix<double,3,1> Matrix_odom;
                Eigen::Matrix<double,3,1> Matrix_odom_rt;
                Matrix_odom<<odomsg->pose.pose.position.x,odomsg->pose.pose.position.y,0;
                Matrix_odom_rt=Matrix_r * Matrix_odom + Matrix_t;
                //merge_utm.x=Matrix_r*odomsg->pose.pose.position.x+Matrix_t;
		//merge_utm.y=Matrix_r*odomsg->pose.pose.position.y+Matrix_t;
                merge_utm.x=Matrix_odom_rt(0,0);
                merge_utm.y=Matrix_odom_rt(1,0);
                //std::cout << "init_lio_x" << init_lio_x<<std::endl;
                //std::cout << "gps_x" << gps_x<<std::endl;
                //std::cout << "new_lio_x-init_lio_x" << (new_lio_x-init_lio_x)<<std::endl;
		//std::cout << "merge_utm.x" << merge_utm.x<<std::endl;
		printf("merge_utm.x%.8f\n",merge_utm.x);
        printf("merge_utm.y%.8f\n",merge_utm.y);
        outage_distance=sqrt((odom_point.x-x_outage)*(odom_point.x-x_outage)+(odom_point.y-y_outage)*(odom_point.y-y_outage));
        printf("outage_distance%.8f\n",outage_distance);
        if(outage_distance > 0 && (outage_distance < 2 || outage_distance == 2))
        {
            error=error0_2 ; //error0_2 
        }
        else if(outage_distance > 2 && (outage_distance < 5 || outage_distance == 5))
        {
            error=error2_5;//error2_5
        }
        else if(outage_distance > 5 && (outage_distance < 10 || outage_distance == 10))
        {
            error=error5_10;
        }
        else if(outage_distance > 10 && (outage_distance < 20 || outage_distance == 20))
        {
            error=error10_20;
        }
        else if(outage_distance > 20 && (outage_distance < 30 || outage_distance == 30))
        {
            error=error20_30;
        }
        else if(outage_distance > 30 && (outage_distance < 40 || outage_distance == 40))
        {
            error=error30_40;
        }
        else if(outage_distance > 40 && (outage_distance < 50 || outage_distance == 50))
        {
            error=error40_50;
        }else if(outage_distance > 50 || covariance1 > 10e-7 || covariance2 > 10e-7)
        {
            error=1000000;
        }
		//std::cout << "merge_utm.y" <<merge_utm.y<< std::endl;
		UTMXYToLatLon(merge_utm,50,0,merge_wgs);	
		//pmsg.lon=merge_lon;
		//pmsg.lat=merge_lat;
        
		pmsg.lon=merge_wgs.lon*FUDU;
		pmsg.lat=merge_wgs.lat*FUDU;
        pmsg.error=error;
 	//发布lio-sam数据
       	pub_merge.publish(pmsg);
		std::cout << "发布merge数据" << std::endl;
 		
		printf("pmsg.lon%.8f\n",pmsg.lon);
		printf("pmsg.lat%.8f\n",pmsg.lat);
		//}

                
	
     	  }

	
	//Odomsg.pose.pose.position.x=detal_lio_x;
	//Odomsg.pose.pose.position.y=detal_lio_y;

	

	//printf("merge_lat%.8f\n",merge_lat);
	//printf("merge_lon%.8f\n",merge_lon);

      

}
/*
/// @brief nodeA、nodeB共同回调函数
/// @param odomsg nodeB 消息结构指针对象
/// @param chccgi nodeA 消息对象
void SubscribeAndPublish::callbackAB(const precisedocking::chccgi610nav::ConstPtr &chccgi,const nav_msgs::OdometryConstPtr &odomsg)
{
    
    int snwm = chccgi->nsv1;
    std::cout << "snwm:" <<snwm<< std::endl;
    int hdop = chccgi->hdop;
    //如果满足条件说明，GPS信号正常，即不在装载区
    if (snwm < 5)
    {
        //在装载区
        isGPSonline = false;
    }
    if (snwm > 5)
    {
        //在装载区
        isGPSonline = true;
    }
    pmsg.gpsweek = chccgi->gpsweek;
    pmsg.gpstime = chccgi->gpstime;
    pmsg.alt = chccgi->alt;
    //如果GPS在线，且不在装载区或过磅区，则由node A发布经纬度
    if (isGPSonline)
    {
        pmsg.header = chccgi->header;
        pmsg.pitch = chccgi->pitch;
        pmsg.roll = chccgi->roll;
        pmsg.heading = chccgi->heading;
        pmsg.lat = chccgi->lat;
        pmsg.lon = chccgi->lon;

        //发布数据
	std::cout << "发布GPS数据" << std::endl;
        pub_merge.publish(pmsg);
    }
    if (!isGPSonline)
    {
      //创建融合数据对象 使用nav_msg::Odometry对象接收
        nav_msgs::Odometry Odomsg;
        pmsg.header = odomsg->header;
	//进入装载区
       // isloadingarea = true;
        UtmToLatandlon(Odomsg, pmsg); //直角坐标转经纬度
 	//发布lio-sam数据
        pub_merge.publish(pmsg);
    }
  
}
*/
/*
/// @brief nodeB、nodeC共同回调函数
/// @param odomsg nodeB 消息结构指针对象
/// @param aprilmsg nodeC 消息结构指针对象
void SubscribeAndPublish::callbackBC(const nav_msgs::OdometryConstPtr &odomsg, const precisedocking::AprilTagDetectionArrayConstPtr &aprilmsg)
{
    //判断如果当前未识别到标签，则返回
    if (aprilmsg->detections.empty())
    {
        return;
    }
    //遍历标签对象数组
    for (auto it = aprilmsg->detections.begin(); it != aprilmsg->detections.end(); it++)
    {
        //创建融合数据对象 使用nav_msg::Odometry对象接收
        nav_msgs::Odometry Odomsg;
        pmsg.header = odomsg->header;
        //融合nodeB、nodeC两个节点的x、y、z
        Odomsg.pose.pose.position.x = (odomsg->pose.pose.position.x + it->pose.pose.pose.position.x) / 2;
        Odomsg.pose.pose.position.y = (odomsg->pose.pose.position.y + it->pose.pose.pose.position.y) / 2;
        Odomsg.pose.pose.position.z = (odomsg->pose.pose.position.z + it->pose.pose.pose.position.z) / 2;
        //计算到标签的距离
        float distance = sqrt(Odomsg.pose.pose.position.x * Odomsg.pose.pose.position.x + Odomsg.pose.pose.position.y * Odomsg.pose.pose.position.y); //需要修改，减掉标签的坐标
        //如果标签的id是 loading_in_tag 并且距离小于15米，则表示进入装载区 由融合节点分布数据
        if (it->id[0] == loading_in_tag && distance < 15)
        {
            //进入装载区
            isloadingarea = true;
            UtmToLatandlon(Odomsg, pmsg); //直角坐标转经纬度
            //融合nodeB、nodeC两个节点的四元数x、y、z、w
            Odomsg.pose.pose.orientation.x = (odomsg->pose.pose.orientation.x + it->pose.pose.pose.orientation.x) / 2;
            Odomsg.pose.pose.orientation.y = (odomsg->pose.pose.orientation.y + it->pose.pose.pose.orientation.y) / 2;
            Odomsg.pose.pose.orientation.z = (odomsg->pose.pose.orientation.z + it->pose.pose.pose.orientation.z) / 2;
            Odomsg.pose.pose.orientation.w = (odomsg->pose.pose.orientation.w + it->pose.pose.pose.orientation.w) / 2;
            getrpy(Odomsg, pmsg); //四元数转roll、pitch、yaw
            //发布融合数据
            pub_merge.publish(pmsg);
        }
        //如果标签的id是 loading_out_tag 且 距离小于5米，并且nodeA正常工作，则表示离开装载区
        else if (it->id[0] == loading_out_tag && distance < 5 && isGPSonline)
        {
            //离开装载区
            isloadingarea = false;
        }
        //如果标签的id是 weighting_in_tag 并且距离小于15米，则表示进入过磅区 由融合节点发布数据
        else if (it->id[0] == weighting_in_tag && distance < 15)
        {
            //进入过磅区
            isweighingarea = true;
            UtmToLatandlon(Odomsg, pmsg); //直角坐标转经纬度
            Odomsg.pose.pose.orientation.x = (odomsg->pose.pose.orientation.x + it->pose.pose.pose.orientation.x) / 2;
            Odomsg.pose.pose.orientation.y = (odomsg->pose.pose.orientation.y + it->pose.pose.pose.orientation.y) / 2;
            Odomsg.pose.pose.orientation.z = (odomsg->pose.pose.orientation.z + it->pose.pose.pose.orientation.z) / 2;
            Odomsg.pose.pose.orientation.w = (odomsg->pose.pose.orientation.w + it->pose.pose.pose.orientation.w) / 2;
            getrpy(Odomsg, pmsg); //四元数转roll、pitch、yaw
            //发布数据
            pub_merge.publish(pmsg);
        }
        //如果标签的id是 weighting_out_tag 且 距离小于5米，则表示离开装载区
        else if (it->id[0] == weighting_out_tag && distance < 5)
        {
            //离开过磅区
            isweighingarea = false;
        }
    }
}
*/
int main(int argc, char *argv[])
{
//gps

//float lio_z=0;
    
    ros::init(argc, argv, "precisedocking_process");
    ros::NodeHandle n;

    ros::param::get("~merge_msg_out_topic", merge_msg_out_topic_);
    ros::param::get("~SNWM", SNWM);
    //ros::param::get("~error0_2", error0_2);
    n.param<double>("error/error0_2", error0_2,0.03);
    n.param<double>("error/error2_5", error2_5,0.05);
    n.param<double>("error/error5_10", error5_10);
    n.param<double>("error/error10_20", error10_20, 0.1);
    n.param<double>("error/error20_30", error20_30, 0.12);
    n.param<double>("error/error30_40", error30_40, 0.15);
    n.param<double>("error/error40_50", error40_50, 2);
    
    
    ROS_INFO("SNWM=%d",SNWM);
    ROS_INFO("error5_10=%f",error5_10);
    ROS_INFO("Ready!");

    SubscribeAndPublish test(n);
    return 0;
}
