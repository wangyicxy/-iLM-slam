source ~/data/dkt/devel/setup.bash
sleep 1
/usr/bin/expect<<-EOF
   set time 30
   spawn sudo chmod 777 /dev/ttysWK1
   expect {
   "password for nvidia" {send "nvidia\r"}
   }
   expect eof
EOF
sleep 1
source ~/data/workspace/gps_ws/devel/setup.bash
roslaunch gpchc_driver gpchc_driver.launch
