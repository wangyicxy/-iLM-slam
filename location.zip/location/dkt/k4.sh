cd /home/nvidia/data/workspace/vehicle_controll/
source devel/setup.bash
roslaunch mpc_follower  mpc_follower.launch
