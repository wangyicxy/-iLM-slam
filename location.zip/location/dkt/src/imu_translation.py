import rospy
#from sensor_msgs.msg import Image
from Yesense_Sensor_Protocol.msg import Yesense_Sensor_Protocol
from sensor_msgs.msg import Imu
from tf.transformations import quaternion_from_euler
#from geometry_msgs.msg import Pose

class Manager:
	def __init__(self):
		self.sub = rospy.Subscriber(" /yesense_sensor", Yesense_Sensor_Protocol, self.callback, queue_size=20)
		self.pub_concate = rospy.Publisher('/imu/data', Imu, queue_size=20)
	def callback(self, msg):
		ca = Imu()
		ca.header = msg.header
		ca.header.frame_id="imu_link"
		DE2RA=pi/180
		q = quaternion_from_euler(msg.Roll * DE2RA, msg.Pitch * DE2RA, msg.Yaw * DE2RA)
		ca.orientation.x = q[0]
		ca.orientation.y = q[1]
		ca.orientation.z = q[2]
		ca.orientation.w = q[3]
		ca.orientation_covariance  =[0,0,0,0,0,0,0,0,0] 
	
		ca.angular_velocity.x=msg.GYRO_X
		ca.angular_velocity.y=msg.GYRO_Y
		ca.angular_velocity.z=msg.GYRO_Z
		ca.angular_velocity_covariance=[0,0,0,0,0,0,0,0,0] 
	
		ca.linear_acceleration.x=msg.ACC_X
		ca.linear_acceleration.y=msg.ACC_Y
		ca.linear_acceleration.z=msg.ACC_Z
		ca.linear_acceleration_covariance=[0,0,0,0,0,0,0,0,0] 
	self.pub_concate.publish(ca)


rospy.init_node('map', anonymous=True)
Manager()
rospy.spin()





