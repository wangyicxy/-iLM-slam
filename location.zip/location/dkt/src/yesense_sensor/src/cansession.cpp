#include <vector>
#include <string>
#include <sys/socket.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <cstring>
#include <thread>
#include <chrono>
#include <unistd.h>
#include "yesense_sensor/cansession.h"
#include "yesense_sensor/debug.h"


using std::vector;
using std::string;


#define SIOCSCANBAUDRATE        (SIOCDEVPRIVATE+0)
#define SIOCGCANBAUDRATE        (SIOCDEVPRIVATE+1)

#define SOL_CAN_RAW (SOL_CAN_BASE + CAN_RAW)
#define CAN_RAW_FILTER  1
#define CAN_RAW_RECV_OWN_MSGS 0x4

#define SYSTEM_CMD_STRLEN		255
#define MAX_CAN_PORT_NUM		4

#define MAX_CAN_READ_BUF_LEN	10000
#define MAX_CAN_WRITE_BUF_LEN	10000

CanSession::CanSession()
    :_receive_thread(nullptr)
    ,_process_thread(nullptr)
    ,_b_init(false)
    ,_b_exit(false)
{
    _read_repository.set_max_volume(120);
}

CanSession::~CanSession()
{
    _b_exit = true;
    if(_receive_thread) {
        delete _receive_thread;
        _receive_thread = nullptr;
    }
    if(_process_thread) {
        delete _process_thread;
        _process_thread = nullptr;
    }
    if(_clock_thread) {
        delete _clock_thread;
        _clock_thread = nullptr;
    }
}

bool CanSession::init(unsigned char can_port, unsigned int baud)
{
    _b_init = true;
    _can_port = can_port;
    _baudrate = baud;
    vector<string> canseq{"can0", "can1", "can2"};
    //restart port
    string cmdStr = string("ip link set ") + canseq[can_port] + " down";
    system(cmdStr.c_str());
    cmdStr = string("ip link set ") + canseq[can_port]
            + string(" up type can bitrate ") + std::to_string(baud);
    system(cmdStr.c_str());
    //create socket
    if((_CanFd = socket(PF_CAN, SOCK_RAW, CAN_RAW)) < 0) {
        debug_print(ERROR, "can't create can socket\n");
        return false;
    }
    
    ifreq ifr;
    addr.can_family = AF_CAN;
    strcpy(ifr.ifr_name, canseq[can_port].c_str());
    int retval = ioctl(_CanFd,SIOCGIFINDEX, &ifr);
    if(retval && ifr.ifr_ifindex == 0) {
        debug_print(WARNING, "ioctl failed\n");
        close(_CanFd);
        _CanFd = 0;
        return false;
    }
    addr.can_ifindex = ifr.ifr_ifindex;
    ioctl(_CanFd, SIOCGIFNAME, &ifr);

    int recv_own_msgs = 1;		///set loop back:  1 enable 0 disable
    int timestamp_flag = 1;
    //setsockopt(_CanFd, SOL_CAN_RAW, CAN_RAW_RECV_OWN_MSGS,&recv_own_msgs, sizeof(recv_own_msgs));
    setsockopt(_CanFd, SOL_CAN_RAW, CAN_RAW_FD_FRAMES,&recv_own_msgs, sizeof(recv_own_msgs));
    setsockopt(_CanFd, SOL_SOCKET, SO_TIMESTAMPING, &timestamp_flag, sizeof(timestamp_flag));
    if (bind(_CanFd, (struct sockaddr *)&addr, sizeof(addr)) < 0){
        debug_print(ERROR, "Can Socket Bind failed!\n");
        close(_CanFd);
        _CanFd = 0;
        return false;
    }
    _receive_thread = new std::thread(&CanSession::read_func, this);
    _process_thread = new std::thread(&CanSession::process_func, this);
    _clock_thread = new std::thread(&CanSession::connection_detector, this);
    return true;
}

uint CanSession::send(const struct canfd_frame &frame)
{
    //uint write_size = sendto(_CanFd, &frame, sizeof(struct canfd_frame), 0, (struct sockaddr*)&addr, sizeof(addr));
    uint write_size = ::send(_CanFd, &frame, sizeof(struct canfd_frame), 0);
    return write_size;
}

struct canfd_frame CanSession::forge_one_can_frame(unsigned int can_id, const std::vector<unsigned char> &data, bool is_extend)
{
    struct canfd_frame frame;
    if(is_extend) {
        frame.can_id = CAN_EFF_MASK & can_id;
        frame.can_id = frame.can_id | CAN_EFF_FLAG;
    } else {
        frame.can_id = CAN_SFF_MASK & can_id;
    }
    frame.len = data.size();
    for(int i = 0; i < data.size(); ++i) {
        frame.data[i] = data[i];
    }
    return frame;
}

struct canfd_frame CanSession::forge_one_can_frame(unsigned int can_id, const unsigned char *data,bool is_extend,unsigned int len)
{
    struct canfd_frame frame;
    if(is_extend) {
        frame.can_id = CAN_EFF_MASK & can_id;
        frame.can_id = frame.can_id | CAN_EFF_FLAG;
    } else {
        frame.can_id = CAN_SFF_MASK & can_id;
    }
    frame.len = len;
    for(int i = 0; i < len; ++i) {
        frame.data[i] = data[i];
    }
    return frame;
}

void CanSession::data_process(const struct canfd_frame &data)
{
}

void CanSession::process_func()
{
    while (!_b_exit) {
        struct canfd_frame recv_frame = _read_repository.consume();
        set_recvd_true();
        data_process(recv_frame);
    }
}

void CanSession::read_func()
{
    struct canfd_frame readFrame;
    int frame_size = sizeof(struct canfd_frame);
    int recv_byte;
    while (!_b_exit) {
        memset(&readFrame, 0, frame_size);
        recv_byte = recv(_CanFd, &readFrame, frame_size, MSG_WAITALL);
        socklen_t receive_length = sizeof(addr);
        //recv_byte = recvfrom(_CanFd, &readFrame, sizeof(readFrame), 0, (struct sockaddr *)&addr, &receive_length);
        if (recv_byte > 0){
            _read_repository.produce(readFrame);
        }
        else
        {
            usleep(500);
        }
    }
}


void CanSession::connection_detector()
{
    while (!_b_exit)
    {
        std::this_thread::sleep_for(std::chrono::milliseconds(200));
        if(b_recvd) {
            b_connected = true;
        } else {
            b_connected = false;
        }
        b_recvd = false;
    }
}
