#include "yesense_sensor/can_sensor.h"
#include "yesense_sensor/config.h"

int main(int argc, char *argv[])
{
    char buf[1024] = {0};
    getcwd(buf, 1024);
    printf("work path:%s\n", buf);

    Config *config = Config::instance();
    Can_Sensor::CanSensor *can = new Can_Sensor::CanSensor(argc,argv,"main_sensor");
    can->init(config->can_port, config->can_bitrate);
    can->init_node(config->dbc_list[0]);

    while(1){
        sleep(3);
    }

    return 0;
}
