#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <vector>
#include <stdarg.h>
#include "yesense_sensor/debug.h"
#include <boost/filesystem.hpp>
#include <boost/date_time/gregorian/gregorian.hpp>
#include <iostream>
#include "yesense_sensor/bytestring.h"
#include <algorithm>
#include <sys/time.h>
#include <ctime>
#include <chrono>

static pthread_mutex_t debug_file_mutex = PTHREAD_MUTEX_INITIALIZER;
namespace {
    std::string current_logfile_name = "";
    bool logPath_inited = false;
    std::string log_date = "";
    std::string now_date() 
    {
        return boost::gregorian::to_iso_string(boost::gregorian::day_clock::local_day());
    }
    //删除过期log日志
    void delete_expired_logFile()
    {
        std::string     presentPath = boost::filesystem::initial_path<boost::filesystem::path>().string();
        std::string log_folder = presentPath + "/log";
        std::vector<std::string> log_files;
        boost::filesystem::path folder_path (log_folder);
        boost::filesystem::directory_iterator diter(folder_path);
        boost::filesystem::directory_iterator iter_end;
        //收集所有日志文件
        for(; diter != iter_end; ++diter) {
            if(boost::filesystem::is_regular_file(diter->status())) {
                log_files.push_back(diter->path().string());
            }
        }
        //删除多余的文件
        if(log_files.size() > LOGFILE_COUNT) {
            std::sort(log_files.begin(), log_files.end());
            unsigned int extend_count = log_files.size() - LOGFILE_COUNT;
            for(int i = 0; i < extend_count; ++i) {
                boost::filesystem::remove(boost::filesystem::path(log_files[i]));
            }
        }
    }
    void redirect_logfile()
    {
        if(now_date() != log_date) {
            log_date = now_date();
        }
    }
}

void printfunc(enum DEBUG_LEVEL level, const char *funcname, const int line, const char *fmt, ...)
{
    if(level < PRINT_LEVEL) {
        return;
    }

    if(logPath_inited) {
        pthread_mutex_lock(&debug_file_mutex);
        if(now_date() != log_date) {
            redirect_logfile();
            delete_expired_logFile();
        }
        FILE *fp = NULL;
        std::string log_file = std::string("./log/") + log_date + ".log";
        if((fp = fopen( log_file.c_str(), "a")) == NULL) {
            perror("can not open log file");
            pthread_mutex_unlock(&debug_file_mutex);
            return;
        }
        switch (level) {
            case DEBUG:
                fprintf(fp, "[DEBUG] %s:%d ", funcname, line);
                break;
            case INFO:
                fprintf(fp, "[INFO] %s:%d ", funcname, line);
                break;
            case WARNING:
                fprintf(fp, "[WARNING] %s:%d ", funcname, line);
                break;
            case ERROR:
                fprintf(fp, "[ERROR] %s:%d ", funcname, line);
                break;
        }
        //****************print time
        std::time_t time = std::chrono::system_clock::to_time_t(
            std::chrono::system_clock::now());
        std::string time_str = std::ctime(&time);
        fprintf(fp, time_str.c_str());
        fprintf(fp, " ");
        char buf[2048];
        va_list args;
        va_start(args, fmt);
        vsnprintf(buf, sizeof(buf), fmt, args);
        va_end(args);
        fwrite(buf, strlen(buf), 1, fp);
        fwrite("\n", 1, 1, fp);
        fclose(fp);
        pthread_mutex_unlock(&debug_file_mutex);
    } else {
        switch (level) {
            case DEBUG:
                std::cout << "[DEBUG] " << funcname << ":" << line << " ";
                break;
            case INFO:
                std::cout << "[INFO]" << funcname << ":" << line << " ";
                break;
            case WARNING:
                std::cout << "[WARNING] " << funcname << ":" << line << " ";
                break;
            case ERROR:
                std::cout << "[ERROR] " << funcname << ":" << line << " ";
                break;
            }
        char buf[2048];
        va_list args;
        va_start(args, fmt);
        vsnprintf(buf, sizeof(buf), fmt, args);
        va_end(args);
        std::cout << buf << std::endl;
    }
}

void printByte(const ByteString &str)
{
    printf("Byte:");
    for(int i = 0; i < str.size(); ++i) {
        printf(" %02x", str[i]);
    }
    printf("\n");
}

bool init_log()
{
    //获取当前路径
    std::string     presentPath = boost::filesystem::initial_path<boost::filesystem::path>().string();
    std::string log_path = presentPath + "/log";
    //检测文件夹是否存在
    if(!boost::filesystem::exists(log_path)) {
        //不存在则创建
       if(!boost::filesystem::create_directories(log_path)) {
           std::cout << "error: create log path failed" << std::endl;
           return false;
       }
    }
    std::cout << "-=--=-=-=============save log at: " << log_path << std::endl;
    logPath_inited = true;
    //遍历目录 删除过期日志
    delete_expired_logFile();
    redirect_logfile();
}
