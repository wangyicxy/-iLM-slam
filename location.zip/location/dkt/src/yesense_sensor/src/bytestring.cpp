#include "yesense_sensor/bytestring.h"

ByteString::ByteString(const void *str, unsigned long size)

{
    if (str == nullptr || size == 0) {
        m_str = nullptr;
        m_size = 0;
    } else {
        m_str = (char *)malloc(size);
        m_size = size;
        memcpy(m_str, str, size);
    }
}

ByteString::ByteString(const char *str)
{
    if (str == nullptr) {
        m_str = nullptr;
        m_size = 0;
    } else {
        m_str = (char *)malloc(strlen(str));
        m_size = strlen(str);
        memcpy(m_str, str, strlen(str));
    }
}

ByteString::ByteString(int len)
{
    if(len > 0) {
        m_str = (char *)malloc(len);
        memset(m_str, 0, len);
        m_size = len;
    } else {
        m_str = nullptr;
        m_size = 0;
    }
}

ByteString &ByteString::operator=(const ByteString &source)
{
    clearData();
    m_str = (char *)malloc(source.size());
    m_size = source.size();
    memcpy(m_str, source.c_str(), source.size());
}

ByteString &ByteString::operator=(const char *str)
{
    clearData();
    m_str = (char *)malloc(strlen(str));
    m_size = strlen(str);
    memcpy(m_str, str, m_size);
}

char ByteString::toChar(ulong index) const
{
    void *temp = this->begin() + index;
    return *static_cast<char *>(temp);
}

unsigned int ByteString::toUint(ulong index) const
{
    unsigned int tempnum;
    void *temp = this->begin() + index;
    memcpy(&tempnum, temp, sizeof(unsigned int));
    return tempnum;
}

unsigned long ByteString::toUlong(ulong index) const
{
    unsigned long tempnum;
    void *temp = this->begin() + index;
    memcpy(&tempnum, temp, sizeof(ulong));
    return tempnum;
}

int ByteString::toInt(ulong index) const
{
    int tempnum;
    char *temp = this->begin() + index;
    memcpy(&tempnum, temp, sizeof(int));
    return tempnum;
}

short ByteString::toShort(ulong index) const
{
    short tempnum;
    char *temp = this->begin() + index;
    memcpy(&tempnum, temp, sizeof(short));
    return tempnum;
}



double ByteString::toDouble(ulong index) const
{
    double tempnum;
    char *temp = this->begin() + index;
    memcpy(&tempnum, temp, sizeof(double));
    return tempnum;
}

ByteString::~ByteString()
{
    free(m_str);
}
/**
 * @brief 给ByteString 对象重新分配内容
 * @param str
 * @param length
 * @return
 */
ByteString &ByteString::assign(const void *str, unsigned long length)
{
    clearData();
    if (str == nullptr || length == 0) {
        m_str = nullptr;
        m_size = 0;
    } else {
        m_str = (char *)malloc(length);
        m_size = length;
        memcpy(m_str, str, length);
    }
}

ByteString &ByteString::operator+=(ByteString data)
{
    char *tmp = (char *)malloc(data.m_size + m_size);
    memcpy(tmp, m_str, m_size);
    memcpy(tmp + m_size, data.m_str, data.m_size);
    if(m_str) {free(m_str);}
    m_str = tmp;
    m_size += data.m_size;
}


ByteString operator+(const ByteString &prefix, const ByteString &suffix)
{
    ByteString retval(static_cast<int>(prefix.size() + suffix.size()));
    memcpy(retval.begin(), prefix.c_str(), prefix.size());
    memcpy(retval.begin() + prefix.size(), suffix.c_str(), suffix.size());
    return retval;
}
