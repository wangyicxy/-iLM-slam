#include "yesense_sensor/can_sensor.h"

using namespace Can_Sensor;

CanSensor *CanSensor::s_instance = nullptr;
CanSensor::CanSensor()
{
}

CanSensor::CanSensor(int argc, char *argv[],std::string node_name)
{
    ros::init(argc, argv, node_name);
    m_handle = new ros::NodeHandle();
}

CanSensor::~CanSensor()
{
    if(thread_publish_protocol!=nullptr){
        thread_publish_protocol->join();
        delete thread_publish_protocol;
        thread_publish_protocol = nullptr;
    }

    if(thread_deal_with_can!=nullptr){
        thread_deal_with_can->join();
        delete thread_deal_with_can;
        thread_deal_with_can = nullptr;
    }

}


void CanSensor::init_node(std::string dbc_path)
{
    m_pub = m_handle->advertise<yesense_sensor::Yesense_Sensor_Protocol>("/yesense_sensor", 100);
    thread_publish_protocol = new std::thread(&CanSensor::publish_info,this);
    thread_deal_with_can = new std::thread(&CanSensor::deal_with, this);

    {
        std::ifstream idbc(dbc_path);
        m_net = dbcppp::INetwork::LoadDBCFromIs(idbc);
        if(idbc.is_open())
            idbc.close();
    }
}

void CanSensor::publish_info()
{
    ros::Rate loop_rate(200);
	while (ros::ok())
	{
        auto sensor = get_sensor_protocol();
        if(sensor.header.frame_id.size() > 0){
            sensor.header.seq++;
            sensor.header.stamp = ros::Time::now();
            m_pub.publish(sensor);
        }

        loop_rate.sleep();
        ros::spinOnce();
    }
}

void CanSensor::deal_with()
{
    while(true)
    {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        struct multi_pack_frame frame = get_multi_pack_frame();

        if(frame.pgn == 0)
            continue;

        // printf("multi_pack_data:");
        // for (int i = 0; i < frame.can_frame.len;i++){
        //     printf("%X ", frame.can_frame.data[i]);
        // }
        // printf("\n");

        unsigned int tmp_pgn;
        uint64_t can_id;
        uint64_t PF;
        std::unordered_map<uint64_t, const dbcppp::IMessage*> messages;
        for (const dbcppp::IMessage& msg : m_net->Messages())
        {
            can_id = msg.Id();
            PF = (can_id >> 16) & 0x000000FF;
            if (PF < 240)
            { //PDU1
                tmp_pgn = (can_id >> 8) & 0x0000FF00;
            }
            else if(PF >= 240) 
            { //PDU2
                tmp_pgn = (can_id >> 8) & 0x0000FFFF;
            }

            messages.insert(std::make_pair(tmp_pgn, &msg));

            //printf("dbc_pgn:%X\n", tmp_pgn);
        }

        //printf("mult_pgn:%X\n", frame.pgn);

        int i = 0;
        auto iter = messages.find(frame.pgn);
        if (iter != messages.end())
        {
            switch (frame.pgn)
            {
            case 0xFF59:  //case 2633980193: //9cff5921
            {
                yesense_sensor::Yesense_Sensor_Protocol ptcol;
                const dbcppp::IMessage *msg = iter->second;
                // std::cout << "Received Message: " << msg->Name() << "\n";
                for (const dbcppp::ISignal &sig : msg->Signals())
                {
                    const dbcppp::ISignal *mux_sig = msg->MuxSignal();
                    if (sig.MultiplexerIndicator() != dbcppp::ISignal::EMultiplexer::MuxValue ||
                        (mux_sig && mux_sig->Decode(frame.can_frame.data) == sig.MultiplexerSwitchValue()))
                    {
                        
                        // std::cout <<" \t" << sig.Name() << "=" << sig.RawToPhys(sig.Decode(frame.data)) << sig.Unit() << "\n";
                        auto tmp = sig.RawToPhys(sig.Decode(frame.can_frame.data));
                        //printf("signal:%f\n",tmp);
                        if (i == 0)
                        {
                           ptcol.Yaw =tmp;
                            //  if(-180.0<=tmp&&tmp<=90.0){
                            //      ptcol.Yaw=90.0-tmp;
                            // }
                            // else if(90.0<tmp&&tmp<180.0){
                            //      ptcol.Yaw=450.0-tmp;
                            // }
                        }
                        else if (i == 1)
                        {
                            ptcol.Pitch = tmp;
                        }
                        else if (i == 2)
                        {
                            ptcol.Roll = tmp;
                        }
                        else if (i == 3)
                        {
                            ptcol.GYRO_Z = tmp;
                        }
                        else if (i == 4)
                        {
                            ptcol.GYRO_Y = tmp;
                        }
                        else if (i == 5)
                        {
                            ptcol.GYRO_X = tmp;
                        }
                        else if (i == 6)
                        {
                            ptcol.ACC_Z = tmp;
                        }
                        else if (i == 7)
                        {
                            ptcol.ACC_Y = tmp;
                        }
                        else if (i == 8)
                        {
                            ptcol.ACC_X = tmp;
                        }
                        else if (i == 9)
                        {
                            ptcol.TID = tmp;
                        }
                    }
                    ++i;
                }
                ptcol.header.frame_id = "Yesense_Sensor";
                set_sensor_protocol(ptcol);

                // auto f = forge_one_can_frame(2633980193, v, true);
                // send(f);
            }
            break;

            default:
                break;
            }
        }
    }
    
}

void CanSensor::J1939_multi_pack_protocol_broadcast(const struct canfd_frame &frame)
{

    // printf("id:%X\n",frame.can_id);
    // for(int i=0;i<frame.len;i++){
    //      printf("%X ",frame.data[i]);
    // }
    // printf("\n");

    u_int32_t can_id;
    if (frame.can_id & CAN_EFF_FLAG) { //extended frame
        can_id = frame.can_id & CAN_EFF_MASK;
    } else { //standard frame
        can_id = frame.can_id & CAN_SFF_MASK;
    }
    

    //j1939多包传输协议处理
    auto temp_pgn = (can_id >> 8) & 0x0000FF00;
    if (temp_pgn == 60416) // 广播公告消息（TP.CM_BAM）
    {
        assert(frame.data[0] == 32); // 控制字节=32
        m_msg_size = frame.data[2] << 8 | frame.data[1];
        m_bag_count = frame.data[3];
        m_pgn = frame.data[7] << 16 | frame.data[6] << 8 | frame.data[5];
        memset(m_buf, 0, sizeof(m_buf));
    }
    else if(temp_pgn == 60160) //数据传送消息（TP.DT）
    {
        if(frame.data[0]==1){
            m_frame_number = 0; 
        }else{
            if(frame.data[0] - m_frame_number != 1){
                ROS_INFO("%s", "the packet's number error");
                memset(m_buf, 0, sizeof(m_buf));
                return;  //丢弃不连续的帧
            }
        }

        for (int j = 0; j < 7; j++)
        {
            m_buf[m_frame_number * 7 + j] = frame.data[j + 1];
        }

        m_frame_number = frame.data[0];

        if(m_frame_number == m_bag_count){
            struct multi_pack_frame f;
            f.can_frame.can_id = 0;
            f.can_frame.len = m_msg_size;
            f.pgn = m_pgn;
            memset(f.can_frame.data, 0, sizeof(f.can_frame.data));
            memcpy(f.can_frame.data, m_buf, m_msg_size);
            memset(m_buf, 0, sizeof(m_buf));
            set_multi_pack_frame(f);
        }
    }

}

void CanSensor::data_process(const struct canfd_frame &frame)
{
    J1939_multi_pack_protocol_broadcast(frame);
}
