#include "yesense_sensor/config.h"
#include <fstream>
#include <sstream>
#include <iostream>

#include "yesense_sensor/debug.h"
#include "./cjson_object/CJsonObject.hpp"
using neb::CJsonObject;
using std::ifstream;
using std::stringstream;

using namespace std;
Config *Config::s_instance = nullptr;
Config::Config()
{
    CJsonObject *load_config = read_json(config_file);
    if(load_config == nullptr) {
        debug_print(ERROR, "can not load config file");
        exit(1);
    }

    load_config->Get("can_port", can_port);
    load_config->Get("can_bitrate", can_bitrate);
   ///load_config->Get("dbc_file_path", dbc_file_path);

    unsigned short count = ((*load_config)["dbc_file_path"]).GetArraySize();
    for(int i = 0; i < count; ++i) {
        dbc_list.push_back(((*load_config)["dbc_file_path"])(i)); 
    }
}

CJsonObject *read_json(const string &path)
{
    CJsonObject *ojson = new CJsonObject;
    ifstream ifin(path);
    if(ifin.good()) {
        stringstream jsonstr;
        jsonstr << ifin.rdbuf();
        if(!ojson->Parse(jsonstr.str())) {
            delete ojson;
            return nullptr;
        } else {
            return ojson;
        }
    } else {
        delete ojson;
        return nullptr;
    }
}
