#ifndef _GENERAL_FUNCTION_
#define _GENERAL_FUNCTION_
#include <chrono>
#include <boost/date_time/gregorian/gregorian.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

class GeneralFunction {
    
public:
    static int64_t present_time()
    {
        std::chrono::milliseconds ms = std::chrono::duration_cast< std::chrono::milliseconds >(
                std::chrono::system_clock::now().time_since_epoch());
        return ms.count();
    }

    static std::string now_time()
    {
        return boost::posix_time::to_simple_string(boost::posix_time::microsec_clock::local_time());
    }

};



#endif //_GENERAL_FUNCTION_
