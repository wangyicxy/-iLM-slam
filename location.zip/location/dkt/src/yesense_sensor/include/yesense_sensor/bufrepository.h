#ifndef BUFREPOSITORY_H
#define BUFREPOSITORY_H

#include <list>
#include <mutex>
#include <condition_variable>

#define MAX_VOLUME  12 //资源中同一时间最多保存12帧待发送的报文
using std::list;

/**
 * @brief   BufRepostory is a thread safe repository for reserving any types of buffer,
 *                  you just need to declear what kind of type you want save by using :
 *                  BufRepostory<Type_you_want> buf;
 */
template <typename T>
class BufRepository
{
public:
    BufRepository(int default_size = MAX_VOLUME)
        :max_size(default_size), cur_size(0), _exit(false){}
    virtual ~BufRepository(){ exit();}
    T consume();
    void produce(const T &buf);
    void produce_front(const T &buf);
    void set_max_volume(int size) {max_size = size;}
    void exit() {_exit = true; is_not_empty.notify_all(); is_not_full.notify_all();};
private:

    int max_size;
    int cur_size;
    std::mutex mutex;
    std::condition_variable is_not_full;
    std::condition_variable is_not_empty;
    list<T> repository;
    bool _exit;
};

template <typename T>
T BufRepository<T>::consume()
{
    std::unique_lock<std::mutex> lock(mutex);
    while(cur_size == 0) {
        if(_exit) {
            lock.unlock();
            T ret;
            return ret;
        }
        this->is_not_empty.wait(lock); //已空，释放锁，等待被其他线程唤醒
    }

    T ret = repository.front();
    repository.pop_front();
    --cur_size;
    lock.unlock();
    if(cur_size == max_size - 1) {
        is_not_full.notify_one();
    }
    return ret;
}

template <typename T>
void BufRepository<T>::produce(const T &buf)
{
    std::unique_lock<std::mutex> lock(mutex);
    while(cur_size == max_size) {
        if(_exit) {
            lock.unlock();
            return;
        }
        this->is_not_full.wait(lock); //已满，释放锁，等待被其他线程唤醒
    }
    repository.push_back(buf);
    ++cur_size;
    lock.unlock();
    if(cur_size == 1) {
        is_not_empty.notify_one();
    }
}

template <typename T>
void BufRepository<T>::produce_front(const T &buf)
{
    std::unique_lock<std::mutex> lock(mutex);
    if(cur_size == max_size) {
       if(_exit) {
            lock.unlock();
            return;
        }
        this->is_not_full.wait(lock);
    }
    repository.push_front(buf);
    ++cur_size;
    lock.unlock();
    if(cur_size == 1) {
        is_not_empty.notify_one();
    }
}

//template <typename T>
//void BufRepository<T>::print_repository()
//{
//    for(auto i : repository) {
//        printByte(i);
//    }
//}
//template <>
//class BufRepository<ByteString>; //@todo 模板实例化无法编译通过

#endif // BUFREPOSITORY_H
