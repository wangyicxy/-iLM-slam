#ifndef CAN_SENSOR_H
#define CAN_SENSOR_H

#include <ros/ros.h>
#include "cansession.h"
#include <fstream>
#include "dbcppp/Network.h"
#include "yesense_sensor/Yesense_Sensor_Protocol.h"


namespace Can_Sensor{

// typedef struct 
// {
//     double Yaw;
//     double Pitch;
//     double Roll;
//     double GYRO_Z ;
//     double GYRO_Y;
//     double GYRO_X;
//     double ACC_Z;
//     double ACC_Y;
//     double ACC_X;
//     unsigned short TID;
// }Yesense_Sensor_Protocol;

struct multi_pack_frame{
    struct canfd_frame can_frame;
    unsigned int pgn;
};

class CanSensor : public CanSession
{
public:
    CanSensor();
    CanSensor(int argc, char *argv[],std::string node_name);
    virtual ~CanSensor();

    static CanSensor* instance();
    void data_process(const struct canfd_frame &data) override;
    void J1939_multi_pack_protocol_broadcast(const struct canfd_frame &frame);
    void init_node(std::string dbc_path);
    void publish_info();
    void deal_with();

    void set_sensor_protocol(const yesense_sensor::Yesense_Sensor_Protocol& protocol);
    yesense_sensor::Yesense_Sensor_Protocol get_sensor_protocol();

    void set_multi_pack_frame(const struct multi_pack_frame& frame);
    struct multi_pack_frame get_multi_pack_frame();

private:
    static CanSensor *s_instance;
    std::mutex mtx_sensor;
    std::mutex mtx_can;
    ros::NodeHandle *m_handle = nullptr;
    ros::Publisher m_pub;
    std::thread *thread_publish_protocol = nullptr;
    std::thread *thread_deal_with_can = nullptr;
    yesense_sensor::Yesense_Sensor_Protocol m_sensor_protocol;
    std::unique_ptr<dbcppp::INetwork> m_net;

    unsigned char m_buf[64] = {0};
    struct multi_pack_frame m_pack_frame; //带pgn的报文
    unsigned int m_bag_count = 0;     //全部数据包的数
    unsigned int m_msg_size = 0;      //整个消息大小的字节数
    unsigned int m_pgn = 0;           //打包消息的参数组编号
    unsigned char m_frame_number = 0; //当前包的编号

};

inline CanSensor* CanSensor::instance(){
    if(s_instance == nullptr){
        s_instance = new CanSensor();
    }
    return s_instance;
}



inline void CanSensor::set_sensor_protocol(const yesense_sensor::Yesense_Sensor_Protocol& protocol)
{
    mtx_sensor.lock();
    m_sensor_protocol = protocol;
    mtx_sensor.unlock();
}

inline yesense_sensor::Yesense_Sensor_Protocol CanSensor::get_sensor_protocol()
{
    std::lock_guard<std::mutex> lock(mtx_sensor);
    return m_sensor_protocol;
}

inline void CanSensor::set_multi_pack_frame(const struct multi_pack_frame &frame)
{
    mtx_can.lock();
    memcpy(&m_pack_frame, &frame, sizeof(frame));
    mtx_can.unlock();
}

inline struct multi_pack_frame CanSensor::get_multi_pack_frame()
{
    std::lock_guard<std::mutex> lock(mtx_can);
    return m_pack_frame;
}

};

#endif