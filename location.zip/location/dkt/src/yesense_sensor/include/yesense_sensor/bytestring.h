#ifndef BYTESTRING_H
#define BYTESTRING_H

#include <string>
#include <cstring>
#include <cstdlib>

class ByteString {
public:
    ByteString(const void *str, unsigned long size);
    explicit ByteString(const char *str);
    explicit ByteString(int size);
    ByteString() :m_str(nullptr), m_size(0) {}
    ByteString(const ByteString &source)
        :ByteString(source.c_str(), source.size()){}
    ByteString &operator=(const ByteString &source);
    ByteString &operator=(const char *str);

    char &operator[](const int &i) {
        if(i < m_size) {
            return *(m_str + i);
        }
    }
    char operator[](const int &i) const {
        if(i < m_size) {
            return *(m_str + i);
        }
    }
    void clear();
    ByteString &calloc(int size);
    char *begin() {
        return m_str;
    }
    char *begin() const {
        return m_str;
    }
    char *end() const {
        return m_str + m_size;
    }
    char *end() {
        return m_str + m_size;
    }
    char toChar(ulong index) const;
    unsigned int toUint(ulong index) const;
    unsigned long toUlong(ulong index) const;
    int toInt(ulong index) const;
    short toShort(ulong index) const;
    double toDouble(ulong index) const;
    ~ByteString();
    ByteString &assign(const void *str, unsigned long length);
    ByteString &operator+=(ByteString data);

    template<typename T>
    ByteString &append(const T &data);
    //特例化
    ByteString &append(const ByteString &data){ this->operator+=(data); }

    char *c_str() const {return m_str;}
    unsigned long size() const {return m_size;}
private:
    void clearData() {if(m_str) delete m_str; m_size = 0;}
    char *m_str;
    unsigned long m_size;
};

template<typename T>
ByteString &ByteString::append(const T &data)
{
    char *tmp = (char *)malloc(sizeof(T) + m_size);
    memcpy(tmp, m_str, m_size);
    memcpy(tmp + m_size, &data, sizeof(T));
    if(m_str) {free(m_str);}
    m_str = tmp;
    m_size += sizeof (T);
}

inline ByteString &ByteString::calloc(int size)
{    if(m_str != nullptr) {
        delete m_str;
        m_str = nullptr;
    }
    clearData();
    m_size = size;
    m_str = (char *)::calloc(size, sizeof(char));
}

inline void ByteString::clear()
{
    if(m_str != nullptr) {
        delete m_str;
        m_str = nullptr;
    }
    m_size = 0;
}

ByteString operator+(const ByteString &prefix, const ByteString &suffix);

#endif // BYTESTRING_H
