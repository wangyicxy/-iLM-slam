#ifndef __DEBUG_H__
#define __DEBUG_H__
enum DEBUG_LEVEL{
    DEBUG   = 0,
    INFO    = 1,
    WARNING = 2,
    ERROR   = 3
};
class ByteString;

#ifndef PRINT_LEVEL
// 日志打印等级
#define PRINT_LEVEL 0
#endif
#ifndef LOGFILE_COUNT
   //日志保存时间
#define LOGFILE_COUNT 15
#endif
#define debug_print(level, fmt...) printfunc(level, __func__, __LINE__, fmt)
void printfunc(enum DEBUG_LEVEL level, const char *funcname, const int line, const char *fmt, ...);
void printByte(const ByteString &data);

bool init_log();
#include <iostream>
#endif
