#ifndef CONFIG_H
#define CONFIG_H
#include <string>
#include <vector>
using std::string;
using std::vector;

#ifndef config_file
    #define config_file "./yesense_sensor_protocol.json"
#endif

namespace neb {
    class CJsonObject;
}

class Config
{
public:
    static Config *instance();
    int can_port;
    int can_bitrate;
    vector<string> dbc_list;

private:
    Config();
    static Config *s_instance;
};

inline Config *Config::instance() 
{
    if(s_instance == nullptr) {
        s_instance = new Config();
        return s_instance;
    }  else {
        return s_instance;
    }
}

neb::CJsonObject *read_json(const std::string &path);

#endif // CONFIG_H
