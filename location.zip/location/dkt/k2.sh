source ~/data/dkt/devel/setup.bash
/usr/bin/expect<<-EOF
   set time 30
   spawn sudo chmod 777 /home/nvidia/can.sh
   expect {
   "*password for nvidia*" {send "nvidia\r"}
   }
   expect eof
EOF
sleep 1
/usr/bin/expect<<-EOF
   set time 40
   spawn sh /home/nvidia/can.sh
   expect {
   "password for nvidia" {send "nvidia\r"}
   }
   expect eof 
EOF
sleep 1
source ~/autoware.sh
