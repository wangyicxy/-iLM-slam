# HesaiLidar_General_ROS

星期二, 17. 十一月 2020 15:25下午 
##version
PandarGeneralROS_1.0.1 

##modify
1. first update

星期三, 09. 十二月 2020 16:25下午 
##version
PandarGeneralROS_1.1.1 

##modify
1. support multiple sensors
2. support GPS port not hard bind 

星期三, 16. 十二月 2020 20:25下午 
##version
PandarGeneralROS_1.1.2

##modify
1. modify msg data size 

星期二, 05. 一月 2021 17:00下午 
##version
PandarGeneralROS_1.1.3

##modify
1. fix the problem in playing rosbag when timestamp is realtime
2. optimize computational efficiency 
3. change readme

星期一, 01. 二月 2021 17:30下午 
##version
PandarGeneralROS_1.1.4

##modify
1. Add correction file of all lidars and set Pandar64.csv as the defalut correction file
2. Support multicast
3. Save correction file in rosbag

星期二, 02. 三月 2021 17:30下午 
##version
PandarGeneralROS_1.1.5

##modify
1. Add coordinate correction for PandarXT and PandarQT

星期一, 08. 三月 2021 17:30下午 
##version
PandarGeneralROS_1.1.6

##modify
1. Fix bug in caculate pointXYZ of PandarQT

星期一, 29. 三月 2021 17:30下午 
##version
PandarGeneralROS_1.1.7

##modify
1. Support run as nodelet
2. Add  print flag
3. Set pthread priority of RecvTask
4. Optimize calculation efficiency

Wednesday, April 6th, 2021 17:30
##version
PandarGeneralSDK_1.1.8

##modify
1. Support XTM


Sunday, August 15th, 2021 17:30
##version
PandarGeneralSDK_1.1.11

##modify
1. Support ubuntu 20.04
2. Support set fov
3. Fix bug in calculate sin and cos
4. Change XT firetime parameter

Sunday, August 22th, 2021 17:30
##version
PandarGeneralSDK_1.1.12

##modify
1. Chang return type to void of function without return
